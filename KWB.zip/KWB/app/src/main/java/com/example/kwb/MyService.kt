package com.example.kwb

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout


class MyService : Service() {


    override fun onBind(intent: Intent): IBinder? {
        return null
    }
    private var mView: View? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val shared:SharedPreference = SharedPreference(this)
        mView = LinearLayout(this)
        (mView as LinearLayout).setBackgroundColor(shared.getColor())

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            280,
            PixelFormat.TRANSLUCENT
        )
        val windowManager = (getSystemService(WINDOW_SERVICE) as WindowManager)!!
        windowManager.addView(mView, layoutParams)


        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        var wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.removeView(mView);

    }
}