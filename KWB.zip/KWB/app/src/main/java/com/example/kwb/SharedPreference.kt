package com.example.kwb

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color


class SharedPreference {
    private var mSharedPreferences: SharedPreferences? = null
    constructor(context: Context) {
        mSharedPreferences = context.getSharedPreferences("SCREEN_FILTER_PREF", Context.MODE_PRIVATE)
    }

    fun getValue(prop: String, def: Int): Int {
        return mSharedPreferences!!.getInt(prop, def)
    }

    private fun getAlpha(): Int {
        return getValue("alpha", 0x33)
    }

    private fun getRed(): Int {
        return getValue("red", 0x00)
    }

    private fun getGreen(): Int {
        return getValue("green", 0x00)
    }

    private fun getBlue(): Int {
        return getValue("blue", 0x00)
    }

    private fun setValue(value: String, v: Int) {
        mSharedPreferences!!.edit().putInt(value, v).apply()
    }

    fun setAlpha(`val`: Int) {
        setValue("alpha", `val`)
    }

    fun setRed(`val`: Int) {
        setValue("red", `val`)
    }

    fun setGreen(`val`: Int) {
        setValue("green", `val`)
    }

    fun setBlue(`val`: Int) {
        setValue("blue", `val`)
    }

    fun getColor(): Int {
        return Color.argb(getAlpha(), getRed(), getGreen(), getBlue())
    }

}